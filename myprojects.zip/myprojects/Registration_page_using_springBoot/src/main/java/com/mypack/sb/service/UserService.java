package com.mypack.sb.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.mypack.sb.model.User;
import com.mypack.sb.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
